# Taller Git
Este repositorio es creado con el objetivo de instruir a los fundamentos de Git y Github con el fin dar los conceptos más básicos para correcto uso e implementacion de esta herramienta muy solicitada para los desarrolladores de software.

# Temas abarcados
* Fundamentos
* Comandos Básicos
* Iniciar un repositorio local
* Ciclo de vida de un archivo
* Repositorios remotos
* Ramificaciones
* Herramientas
* El portal Github

# Que deberias leer
* [Historia de Git](https://git-scm.com/book/es/v1/Empezando-Una-breve-historia-de-Git)
* [Semantic Versioning](https://medium.com/@jameshamann/a-brief-guide-to-semantic-versioning-c6055d87c90e)

# Extras
Se te adjuntan dentro de este repositorio algunos PDF's y material que te serviran de mucha ayuda. Te invito a que les des una leida.

# Tarea-01
- Crear una cuenta en Github
- Crear un repositorio local y remoto (subirlo posteriormente a github)
- Con al menos 3 carpetas
- Al menos 5 archivos
- 1 archivo README.md de documentación que incluya como usar:
    - Headers
    - Listas
    - Imagenes
    - Urls
    - Codigo
    - Citas
    - Emojis
    - etc... (todo esto relacionado a los archivos Markdown)
- Al menos 10 commits
- 2 tags
- 2 ramas
- 1 archivo .gitignore (debes agregar archivos/carpetas que ignorar)
- Al menos 1 archivo .gitkeep (para carpetas vacías pero que quieras que aparezcan en el repo)